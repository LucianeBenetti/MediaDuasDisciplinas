package luciane.senac.mediaduasdisciplinas.uteis;

public class Constantes {
    public static class Parametros{
        public static String DISCIPLINA1 = "d1";
        public static String DISCIPLINA2 = "d2";
    }
    public static class Nota{
        public static int MAXIMO = 10;
        public static int MINIMO = 0;
        public static int MEDIA_APROVACAO = 7;
    }
}
